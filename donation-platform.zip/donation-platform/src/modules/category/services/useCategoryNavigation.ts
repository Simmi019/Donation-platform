import { useNavigate } from "react-router-dom";

const useCategoryNavigation = () => {
  const navigate = useNavigate();

  const handleNavigation = (selectedRole: string | null) => {
    if (!selectedRole) return;
    
    const routeMap: Record<string, string> = {
      Donor: "/donor",
      Receiver: "/receiver",
    };

    const path = routeMap[selectedRole] || "/";
    navigate(path);
  };

  return handleNavigation;
};

export default useCategoryNavigation;
