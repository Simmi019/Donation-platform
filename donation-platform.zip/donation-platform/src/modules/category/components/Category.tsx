import { useState } from "react";
// import categoryNavigation from "../services/categoryNavigation";
import useCategoryNavigation from "../services/useCategoryNavigation";
// import useNavigateRole from "../hooks/useNavigateRole"; // Adjust path as needed

const Category = () => {
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const handleNavigation = useCategoryNavigation();

  return (
    <div className="w-[100%] bg-[#fdf2e8]">
      <div className="w-[90%] h-[100vh] mx-auto flex items-center justify-center">
        <div className="w-[50%]">
          <img src="/src/assets/HomeCategory.png" className="w-[100%] h-[70vh] mt-[6%]" alt="Home Category" />
        </div>
        <div className="w-[50%]">
          <div className="flex justify-center items-center bg-[#fdf2e8] p-4 h-[70vh] mt-[6%]">
            <div className="bg-white shadow-lg rounded-lg p-6 w-full max-w-lg">
              <h3 className="text-lg font-semibold mb-2">Choose your role</h3>
              <div className="space-y-3">
                {["Donor", "Receiver"].map((role) => (
                  <label key={role} className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-100">
                    <input
                      type="radio"
                      name="role"
                      className="w-5 h-5"
                      value={role}
                      onChange={() => setSelectedRole(role)}
                      checked={selectedRole === role}
                    />
                    <div>
                      <span className="font-bold">{role}</span>
                      <p className="text-sm text-gray-500">
                        {role === "Donor"
                          ? "Donate the items to the needful."
                          : role === "Receiver"
                          ? "Pickup and deliver items to the needful."
                          : "Deliver items to the needful."}
                      </p>
                    </div>
                  </label>
                ))}
              </div>

              <button
                className={`mt-5 w-full bg-[#212121] text-white py-3 rounded-lg ${
                  selectedRole ? "hover:bg-[#505050] transition" : "opacity-50 cursor-not-allowed"
                }`}
                onClick={() => handleNavigation(selectedRole)}
                disabled={!selectedRole}
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Category;
