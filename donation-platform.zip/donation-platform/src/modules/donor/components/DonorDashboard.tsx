
import type React from "react"
import { useState, useCallback, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle,
  Camera,
  Plus,
  Calendar,
  MapPin,
  Award,
  Clock,
  Heart,
  ThumbsUp,
  Gift,
  Upload,
  XCircle,
  Book,
  Shirt,
  Gamepad2,
  Search,
  Filter,
  AlertTriangle,
  Bell,
  Users,
  TrendingUp,
  Check,
  BarChart,
  Eye,
} from "lucide-react"

// Cloudinary upload preset (you would replace with your actual preset)
const CLOUDINARY_UPLOAD_PRESET = "donor_app_preset"
const CLOUDINARY_CLOUD_NAME = "your_cloud_name"

// Mock real-time data for demonstration
const MOCK_REAL_TIME_UPDATES = [
  { type: "new_request", message: "New request for children's books in your area", time: "Just now" },
  {
    type: "donation_claimed",
    message: "Your winter clothes donation was claimed by Winter Care Initiative",
    time: "2 minutes ago",
  },
  { type: "impact", message: "Your donations have helped 37 people this month!", time: "10 minutes ago" },
  { type: "milestone", message: "You've reached Super Donor status! +500 points", time: "1 hour ago" },
  { type: "community", message: "5 donors just joined from your neighborhood", time: "3 hours ago" },
]

// Mock analytics data
const DONATION_ANALYTICS = {
  monthly: [42, 38, 45, 50, 53, 57, 60],
  impact:40,
  trend: "+12.5%",
  categories: {
    books: 40,
    clothes: 35,
    toys: 25,
  },
  topNeeds: [
    { item: "Children's books", demand: 85 },
    { item: "Winter clothing", demand: 78 },
    { item: "School supplies", demand: 65 },
  ],
}

const DonorApp = () => {
  const [showSuccess, setShowSuccess] = useState(false)
  const [itemTitle, setItemTitle] = useState("")
  const [description, setDescription] = useState("")
  const [itemCategory, setItemCategory] = useState("books")
  const [itemCondition, setItemCondition] = useState("good")
  const [itemQuantity, setItemQuantity] = useState<number>(1)
  const [activeTab, setActiveTab] = useState<string>("myDonations")
  const [images, setImages] = useState<string[]>([])
  const [uploading, setUploading] = useState(false)
  const [pickupDate, setPickupDate] = useState("")
  const [showDonationForm, setShowDonationForm] = useState(false)
  const [realTimeUpdates, setRealTimeUpdates] = useState(MOCK_REAL_TIME_UPDATES)
  const [unreadUpdates, setUnreadUpdates] = useState(3)
  const [showNotifications, setShowNotifications] = useState(false)
  const [donationItems, setDonationItems] = useState<any[]>([
    { id: 1, items: "Jackets", qty: "1", details: "Denim", category: "clothes", time: "just now", status: "active" },
    {
      id: 2,
      items: "Children's Books",
      qty: "12",
      details: "Fiction",
      category: "books",
      time: "2 days ago",
      status: "completed",
    },
    {
      id: 3,
      items: "Board Games",
      qty: "3",
      details: "Educational",
      category: "toys",
      time: "1 week ago",
      status: "completed",
    },
  ])
  const [upcomingPickups, setUpcomingPickups] = useState<any[]>([
    {
      id: 1,
      items: "Jackets",
      receiver: "Winter Care Initiative",
      date: "Tomorrow, 2-4 PM",
      address: "10B, Connaught Place",
    },
  ])
  const [activeFilter, setActiveFilter] = useState<string | null>(null)
  const [pickupTimeWindow, setPickupTimeWindow] = useState<string>("flexible")
  const [isRecurringDonation, setIsRecurringDonation] = useState<boolean>(false)

  // Handle cloudinary upload
  const handleImageUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setUploading(true)

    try {
      const file = files[0]
      const formData = new FormData()
      formData.append("file", file)
      formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET)

      const response = await fetch(`https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.secure_url) {
        setImages((prev) => [...prev, data.secure_url])
      }
    } catch (error) {
      console.error("Error uploading to Cloudinary:", error)
    } finally {
      setUploading(false)
    }
  }, [])

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = () => {
    // Create new donation item
    const newDonation = {
      id: Date.now(),
      items: itemTitle,
      qty: itemQuantity.toString(),
      details: description.substring(0, 15) + (description.length > 15 ? "..." : ""),
      category: itemCategory,
      time: "just now",
      status: "active",
    }

    // Add to donations list
    setDonationItems((prev) => [newDonation, ...prev])

    // Show success message
    setShowSuccess(true)
    setTimeout(() => {
      setShowSuccess(false)
      setShowDonationForm(false)
      setImages([])
      setItemTitle("")
      setDescription("")
      setPickupDate("")
    }, 3000)

    // Simulate real-time update
    setTimeout(() => {
      const newUpdate = {
        type: "donation_posted",
        message: `Your ${itemTitle} donation has been posted and is visible to all receivers`,
        time: "Just now",
      }
      setRealTimeUpdates((prev) => [newUpdate, ...prev])
      setUnreadUpdates((prev) => prev + 1)
    }, 4000)
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "books":
        return <Book className="w-4 h-4" />
      case "clothes":
        return <Shirt className="w-4 h-4" />
      case "toys":
        return <Gamepad2 className="w-4 h-4" />
      default:
        return <Gift className="w-4 h-4" />
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "books":
        return "bg-blue-100 text-blue-800"
      case "clothes":
        return "bg-purple-100 text-purple-800"
      case "toys":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getUpdateIcon = (type: string) => {
    switch (type) {
      case "new_request":
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />
      case "donation_claimed":
        return <Check className="w-4 h-4 text-green-500" />
      case "impact":
        return <Users className="w-4 h-4 text-blue-500" />
      case "milestone":
        return <Award className="w-4 h-4 text-purple-500" />
      case "community":
        return <Heart className="w-4 h-4 text-pink-500" />
      case "donation_posted":
        return <Gift className="w-4 h-4 text-indigo-500" />
      default:
        return <Bell className="w-4 h-4 text-gray-500" />
    }
  }

  // Simulate receiving real-time updates periodically
  useEffect(() => {
    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * MOCK_REAL_TIME_UPDATES.length)
      const update = {
        ...MOCK_REAL_TIME_UPDATES[randomIndex],
        time: "Just now",
      }

      setRealTimeUpdates((prev) => [update, ...prev.slice(0, 9)])
      setUnreadUpdates((prev) => prev + 1)
    }, 45000) // Every 45 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      {/* Header with Real-time Notification Bell */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <Heart className="w-6 h-6 text-pink-500 mr-2" />
          <h1 className="text-2xl font-bold text-indigo-700">DonateShare</h1>
        </div>

        <div className="relative">
          <Button
            variant="ghost"
            size="sm"
            className="relative"
            onClick={() => {
              setShowNotifications(!showNotifications)
              if (showNotifications) setUnreadUpdates(0)
            }}
          >
            <Bell className="w-5 h-5" />
            {unreadUpdates > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {unreadUpdates}
              </span>
            )}
          </Button>

          {/* Notification Panel */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
              <div className="p-3 border-b border-gray-100">
                <h3 className="font-medium">Recent Updates</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {realTimeUpdates.map((update, i) => (
                  <div key={i} className="p-3 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-3 mt-1">{getUpdateIcon(update.type)}</div>
                      <div>
                        <p className="text-sm text-gray-800">{update.message}</p>
                        <p className="text-xs text-gray-500 mt-1">{update.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* User Stats Card */}
      <Card className="bg-white shadow-lg rounded-lg overflow-hidden mb-6 border-0">
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white">Welcome back, Divya</h1>
              <div className="flex items-center mt-1">
                <Badge className="bg-green-500 hover:bg-green-600">
                  <Award className="w-4 h-4 mr-1" /> Super Donor
                </Badge>
              </div>
            </div>
            <div className="h-16 w-16 rounded-full bg-white shadow-md flex items-center justify-center">
              <span className="text-2xl font-bold text-indigo-600">D</span>
            </div>
          </div>
        </div>

        <CardContent className="p-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            {[
              { icon: <Gift className="w-6 h-6 text-indigo-500" />, value: "37", label: "Donations" },
              { icon: <ThumbsUp className="w-6 h-6 text-blue-500" />, value: "25", label: "Feedback" },
              { icon: <Award className="w-6 h-6 text-yellow-500" />, value: "1230", label: "Points" },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center p-3 rounded-lg bg-gray-50">
                <div className="mb-2">{stat.icon}</div>
                <p className="font-bold text-lg text-gray-800">{stat.value}</p>
                <p className="text-gray-500 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Pickups */}
      {upcomingPickups.length > 0 && (
        <Card className="mb-6 border-0 shadow-lg bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold text-yellow-800 flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-yellow-600" /> Upcoming Pickup
              </h2>
            </div>

            {upcomingPickups.map((pickup, i) => (
              <div key={i} className="bg-white p-3 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">{pickup.items}</h3>
                    <p className="text-sm text-gray-600">To: {pickup.receiver}</p>
                    <div className="mt-1 space-y-1">
                      <p className="text-xs text-gray-500 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" /> {pickup.date}
                      </p>
                      <p className="text-xs text-gray-500 flex items-center">
                        <MapPin className="w-3 h-3 mr-1" /> {pickup.address}
                      </p>
                    </div>
                  </div>
                  <div>
                    <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700 text-white">
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Live Activity Feed */}
      <div className="mb-6 px-2 py-3 bg-white bg-opacity-70 rounded-lg shadow-sm border border-indigo-100">
        <div className="flex items-center space-x-2">
          <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div>
          <p className="text-sm text-gray-600">
            <span className="font-medium text-indigo-600">Live:</span> 23 donors active now • 8 new requests in your
            area today
          </p>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
        <TabsList className="w-full grid grid-cols-3 mb-4">
          <TabsTrigger value="myDonations" className="text-sm">
            My Donations
          </TabsTrigger>
          <TabsTrigger value="requests" className="text-sm">
            Receiver Requests
          </TabsTrigger>
          <TabsTrigger value="insights" className="text-sm">
            Insights
          </TabsTrigger>
        </TabsList>

        <TabsContent value="myDonations" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              {donationItems.length === 0 && !showDonationForm ? (
                <div className="text-center py-8">
                  <Gift className="w-12 h-12 text-indigo-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">No active donations yet</p>
                  <p className="text-gray-500 mb-4">Do you have books, toys, or clothes to share with those in need?</p>
                  <Button
                    className="bg-indigo-600 text-white hover:bg-indigo-700 transition flex items-center mx-auto"
                    onClick={() => setShowDonationForm(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" /> Create Donation Post
                  </Button>
                </div>
              ) : !showDonationForm ? (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold">Your Donations</h2>
                    <div className="relative mb-4">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Search your donations"
                        className="pl-10 h-9"
                        onChange={(e) => {
                          const searchTerm = e.target.value.toLowerCase()
                          if (searchTerm === "") {
                            setDonationItems([...donationItems])
                          } else {
                            const filtered = donationItems.filter(
                              (item) =>
                                item.items.toLowerCase().includes(searchTerm) ||
                                item.details.toLowerCase().includes(searchTerm) ||
                                item.category.toLowerCase().includes(searchTerm),
                            )
                            setDonationItems(filtered)
                          }
                        }}
                      />
                    </div>
                    <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className={`whitespace-nowrap ${!activeFilter ? "bg-indigo-50" : ""}`}
                        onClick={() => {
                          setActiveFilter(null)
                          setDonationItems([...donationItems])
                        }}
                      >
                        All
                      </Button>
                      {["active", "completed"].map((status) => (
                        <Button
                          key={status}
                          variant="outline"
                          size="sm"
                          className={`whitespace-nowrap ${activeFilter === status ? "bg-indigo-50" : ""}`}
                          onClick={() => {
                            setActiveFilter(status)
                            const filtered = donationItems.filter((item) => item.status === status)
                            setDonationItems(filtered)
                          }}
                        >
                          {status.charAt(0).toUpperCase() + status.slice(1)}
                        </Button>
                      ))}
                      {["books", "clothes", "toys"].map((category) => (
                        <Button
                          key={category}
                          variant="outline"
                          size="sm"
                          className={`whitespace-nowrap ${activeFilter === category ? "bg-indigo-50" : ""}`}
                          onClick={() => {
                            setActiveFilter(category)
                            const filtered = donationItems.filter((item) => item.category === category)
                            setDonationItems(filtered)
                          }}
                        >
                          <div className="flex items-center">
                            {getCategoryIcon(category)}
                            <span className="ml-1 capitalize">{category}</span>
                          </div>
                        </Button>
                      ))}
                    </div>
                    <Button
                      className="bg-indigo-600 text-white hover:bg-indigo-700 transition flex items-center"
                      onClick={() => setShowDonationForm(true)}
                    >
                      <Plus className="w-4 h-4 mr-2" /> New Donation
                    </Button>
                  </div>

                  <div className="space-y-3">
                    {donationItems.map((donation, i) => (
                      <div key={i} className="p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                        <div className="flex justify-between">
                          <div>
                            <div className="flex items-center">
                              {getCategoryIcon(donation.category)}
                              <h3 className="font-medium ml-1">{donation.items}</h3>
                            </div>
                            <p className="text-gray-500 text-sm">
                              {donation.qty} items | {donation.details}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge
                              className={
                                donation.status === "active"
                                  ? "bg-green-100 text-green-800 hover:bg-green-200"
                                  : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                              }
                            >
                              {donation.status.charAt(0).toUpperCase() + donation.status.slice(1)}
                            </Badge>

                            {donation.status === "active" && (
                              <Button variant="outline" size="sm" className="h-7 text-xs">
                                Edit
                              </Button>
                            )}
                          </div>
                        </div>

                        <div className="flex justify-between items-center mt-2">
                          <p className="text-xs text-gray-500 flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> Posted {donation.time}
                          </p>

                          {donation.status === "active" && (
                            <div className="text-xs text-gray-500">
                              <span className="text-green-600 font-medium">3 views</span> •{" "}
                              <span className="text-indigo-600 font-medium">1 interested</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                /* Donation Form */
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold flex items-center">
                      <Gift className="w-5 h-5 mr-2 text-indigo-500" /> New Donation
                    </h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDonationForm(false)}
                      className="text-gray-500 hover:text-red-500"
                    >
                      <XCircle className="w-5 h-5" />
                    </Button>
                  </div>

                  <Input
                    type="text"
                    placeholder="Item name (e.g. Children's books, Winter clothes)"
                    value={itemTitle}
                    onChange={(e) => setItemTitle(e.target.value)}
                    className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                  />

                  <Textarea
                    placeholder="Description (type, age group, condition, etc.)"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500 min-h-24"
                  />

                  {/* Item Category */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Item Category</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "books", label: "Books", icon: <Book className="w-4 h-4 mr-2" /> },
                        { id: "clothes", label: "Clothes", icon: <Shirt className="w-4 h-4 mr-2" /> },
                        { id: "toys", label: "Toys", icon: <Gamepad2 className="w-4 h-4 mr-2" /> },
                      ].map((cat) => (
                        <Button
                          key={cat.id}
                          type="button"
                          variant={itemCategory === cat.id ? "default" : "outline"}
                          className={itemCategory === cat.id ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          onClick={() => setItemCategory(cat.id)}
                        >
                          <div className="flex items-center">
                            {cat.icon}
                            {cat.label}
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Item Condition */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Item Condition</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "new", label: "New" },
                        { id: "good", label: "Good" },
                        { id: "used", label: "Used" },
                      ].map((cond) => (
                        <Button
                          key={cond.id}
                          type="button"
                          variant={itemCondition === cond.id ? "default" : "outline"}
                          className={itemCondition === cond.id ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          onClick={() => setItemCondition(cond.id)}
                        >
                          {cond.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Quantity Selection */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Quantity</h3>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                      <span className="text-gray-700">Number of items</span>
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 w-8 p-0 rounded-full"
                          onClick={() => setItemQuantity(Math.max(1, itemQuantity - 1))}
                        >
                          -
                        </Button>
                        <span className="w-6 text-center font-medium">{itemQuantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 w-8 p-0 rounded-full"
                          onClick={() => setItemQuantity(itemQuantity + 1)}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Upload Images */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-medium text-gray-700 flex items-center">
                      <Camera className="w-4 h-4 mr-2" /> Item Photos
                    </h3>

                    <div
                      className="border-2 border-dashed border-gray-300 rounded-lg p-4 transition-colors hover:border-indigo-500"
                      onDragOver={(e) => {
                        e.preventDefault()
                        e.currentTarget.classList.add("border-indigo-500", "bg-indigo-50")
                      }}
                      onDragLeave={(e) => {
                        e.currentTarget.classList.remove("border-indigo-500", "bg-indigo-50")
                      }}
                      onDrop={(e) => {
                        e.preventDefault()
                        e.currentTarget.classList.remove("border-indigo-500", "bg-indigo-50")

                        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                          const file = e.dataTransfer.files[0]
                          if (file.type.startsWith("image/")) {
                            const formData = new FormData()
                            formData.append("file", file)
                            formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET)

                            setUploading(true)
                            fetch(`https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`, {
                              method: "POST",
                              body: formData,
                            })
                              .then((response) => response.json())
                              .then((data) => {
                                if (data.secure_url) {
                                  setImages((prev) => [...prev, data.secure_url])
                                }
                              })
                              .catch((error) => {
                                console.error("Error uploading to Cloudinary:", error)
                              })
                              .finally(() => {
                                setUploading(false)
                              })
                          }
                        }
                      }}
                    >
                      <div className="grid grid-cols-4 gap-2">
                        {images.map((img, i) => (
                          <div key={i} className="relative group">
                            <div className="h-24 w-full rounded-lg bg-gray-100 overflow-hidden">
                              <img
                                src={img || "/placeholder.svg"}
                                alt={`Item ${i + 1}`}
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <button
                              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => removeImage(i)}
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </div>
                        ))}

                        {images.length < 4 && (
                          <label className="h-24 w-full rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500 transition-colors">
                            <Upload className="w-6 h-6 text-gray-400" />
                            <span className="text-xs text-gray-500 mt-1">Upload</span>
                            <input
                              type="file"
                              className="hidden"
                              accept="image/*"
                              onChange={handleImageUpload}
                              disabled={uploading}
                            />
                          </label>
                        )}
                      </div>

                      {images.length === 0 && (
                        <div className="text-center mt-2">
                          <p className="text-sm text-gray-500">Drag & drop images here or click to browse</p>
                        </div>
                      )}

                      {uploading && (
                        <div className="mt-2">
                          <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-indigo-500 animate-pulse" style={{ width: "100%" }}></div>
                          </div>
                          <p className="text-xs text-center text-indigo-600 mt-1">Uploading image...</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Pickup Date */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700 flex items-center">
                      <Calendar className="w-4 h-4 mr-2" /> Available for Pickup
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Date</p>
                        <Input
                          type="date"
                          value={pickupDate}
                          onChange={(e) => setPickupDate(e.target.value)}
                          className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Time Window</p>
                        <select
                          className="w-full h-10 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={pickupTimeWindow}
                          onChange={(e) => setPickupTimeWindow(e.target.value)}
                        >
                          <option value="morning">Morning (9AM - 12PM)</option>
                          <option value="afternoon">Afternoon (12PM - 4PM)</option>
                          <option value="evening">Evening (4PM - 7PM)</option>
                          <option value="flexible">Flexible (Anytime)</option>
                        </select>
                      </div>
                    </div>
                    <div className="mt-2">
                      <label className="flex items-center space-x-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          checked={isRecurringDonation}
                          onChange={(e) => setIsRecurringDonation(e.target.checked)}
                        />
                        <span>This is a recurring donation (monthly)</span>
                      </label>
                    </div>
                  </div>

                  {/* Tax deduction note */}
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <InfoIcon className="w-4 h-4 inline mr-1" /> Your donations may be eligible for tax deductions.
                      Keep records of your donations for tax season.
                    </p>
                  </div>

                  {/* Submit Button */}
                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        // Show preview logic would go here
                        alert("Preview functionality would show how your donation post will appear to receivers")
                      }}
                    >
                      <Eye className="w-5 h-5 mr-2" /> Preview
                    </Button>
                    <Button
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white transition"
                      onClick={handleSubmit}
                      disabled={uploading}
                    >
                      <Gift className="w-5 h-5 mr-2" /> Submit Donation
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requests" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold flex items-center">
                  <Heart className="w-5 h-5 mr-2 text-pink-500" /> Donation Requests
                </h2>

                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input placeholder="Search requests" className="pl-8 h-8 w-40 text-sm" />
                  </div>
                  <Button variant="outline" size="sm" className="h-8">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Real-time request notification */}
              <div className="mb-4 p-3 bg-green-50 rounded-lg border border-green-200 flex items-center">
                <div className="flex-shrink-0 mr-3">
                  <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
                </div>
                <p className="text-sm text-green-800">
                  <span className="font-medium">Live updates:</span> Matching requests based on your donation history
                </p>
              </div>

              <div className="space-y-3">
                {[
                  {
                    name: "Helping Hands NGO",
                    request: "Children's Books (Age 5-10)",
                    category: "books",
                    location: "12A, Vasant Kunj, New Delhi",
                    time: "2 hours ago",
                    distance: "3.2 km away",
                    match: 95,
                    urgency: "high",
                  },
                  {
                    name: "Winter Care Initiative",
                    request: "Winter Clothes (All Sizes)",
                    category: "clothes",
                    location: "10B, Connaught Place, New Delhi",
                    time: "5 hours ago",
                    distance: "5.7 km away",
                    match: 88,
                    urgency: "medium",
                  },
                  {
                    name: "Joyful Learning Center",
                    request: "Educational Toys and Games",
                    category: "toys",
                    location: "23C, Greater Kailash, New Delhi",
                    time: "1 day ago",
                    distance: "7.8 km away",
                    match: 75,
                    urgency: "low",
                  },
                ].map((request, i) => (
                  <div key={i} className="p-4 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-medium flex items-center">
                          {request.urgency === "high" && <span className="mr-2 h-2 w-2 bg-red-500 rounded-full"></span>}
                          {request.name}
                        </h3>
                        <p className="text-gray-800 font-medium mt-1 flex items-center">
                          {getCategoryIcon(request.category)}
                          <span className="ml-1">{request.request}</span>
                        </p>
                      </div>
                      <div>
                        <Badge
                          className={`
                          ${
                            request.match > 90
                              ? "bg-green-100 text-green-800"
                              : request.match > 80
                                ? "bg-blue-100 text-blue-800"
                                : "bg-gray-100 text-gray-800"
                          }
                        `}
                        >
                          {request.match}% Match
                        </Badge>
                      </div>
                    </div>

                    <div className="mt-2 text-sm text-gray-500 space-y-1">
                      <p className="flex items-center">
                        <MapPin className="w-3 h-3 mr-1" /> {request.location}
                      </p>
                      <p className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" /> Requested {request.time} • {request.distance}
                      </p>
                    </div>

                    <div className="mt-3 flex space-x-2">
                      <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Donate Now</Button>
                      <Button variant="outline">View Details</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              <h2 className="text-lg font-semibold flex items-center mb-4">
                <BarChart className="w-5 h-5 mr-2 text-indigo-500" /> Your Donation Impact
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-indigo-700 mb-2">Monthly Donations</h3>
                  <div className="h-40 w-full">
                    {/* This would be your chart component */}
                    <div className="h-full w-full bg-white rounded-md flex items-end p-2 space-x-1">
                      {DONATION_ANALYTICS.monthly.map((val, i) => (
                        <div
                          key={i}
                          className="bg-indigo-500 rounded-t w-full"
                          style={{ height: `${(val / 60) * 100}%` }}
                        ></div>
                      ))}
                    </div>
                  </div>
                  <div className="mt-2 flex justify-between text-xs text-gray-500">
                    <span>Jan</span>
                    <span>Feb</span>
                    <span>Mar</span>
                    <span>Apr</span>
                    <span>May</span>
                    <span>Jun</span>
                    <span>Jul</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg border border-gray-100">
                    <h3 className="text-sm font-medium text-gray-500">People Impacted</h3>
                    <div className="mt-2 flex items-baseline">
                      <span className="text-2xl font-bold text-indigo-700">{DONATION_ANALYTICS.impact}</span>
                      <span className="ml-2 text-sm text-green-600">{DONATION_ANALYTICS.trend}</span>
                    </div>
                    <div className="mt-2 text-xs text-gray-500">Since you joined</div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-gray-100">
                    <h3 className="text-sm font-medium text-gray-500">Category Mix</h3>
                    <div className="mt-3 space-y-2">
                      {Object.entries(DONATION_ANALYTICS.categories).map(([category, percentage]) => (
                        <div key={category}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="capitalize">{category}</span>
                            <span>{percentage}%</span>
                          </div>
                          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${
                                category === "books"
                                  ? "bg-blue-500"
                                  : category === "clothes"
                                    ? "bg-purple-500"
                                    : "bg-yellow-500"
                              }`}
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-gray-100 col-span-2">
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Top Needs In Your Area</h3>
                    <div className="space-y-2">
                      {DONATION_ANALYTICS.topNeeds.map((need, i) => (
                        <div key={i} className="flex items-center">
                          <div className="w-full">
                            <div className="flex justify-between text-xs mb-1">
                              <span>{need.item}</span>
                              <span className="text-indigo-600">{need.demand}% demand</span>
                            </div>
                            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div className="h-full bg-indigo-500" style={{ width: `${need.demand}%` }}></div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-lg border border-gray-100 col-span-2 mt-4">
                    <h3 className="text-sm font-medium text-gray-500 mb-3">Your Donation Goals</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Monthly Goal (10 items)</span>
                          <span className="text-indigo-600">7/10 items</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500" style={{ width: "70%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Annual Impact (100 people)</span>
                          <span className="text-indigo-600">78/100 people</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-green-500" style={{ width: "78%" }}></div>
                        </div>
                      </div>
                      <Button className="w-full mt-2 bg-indigo-600 hover:bg-indigo-700 text-white">
                        <TrendingUp className="w-4 h-4 mr-2" /> Set New Goals
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-blue-700 mb-2">Need Donation Ideas?</h3>
                <p className="text-sm text-blue-600 mb-3">
                  Based on your donation history and local needs, we recommend:
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: "Primary School Books", icon: <Book className="w-4 h-4 mr-1" /> },
                    { label: "Winter Jackets", icon: <Shirt className="w-4 h-4 mr-1" /> },
                    { label: "Board Games", icon: <Gamepad2 className="w-4 h-4 mr-1" /> },
                  ].map((item, i) => (
                    <Button key={i} variant="outline" className="bg-white text-xs h-auto py-2 text-gray-700">
                      {item.icon}
                      {item.label}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Success Message Overlay */}
      {showSuccess && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-md">
            <div className="text-center">
              <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-green-100">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Donation Posted Successfully!</h3>
              <p className="text-gray-500 mb-4">
                Your donation is now visible to receivers. We'll notify you when someone is interested.
              </p>
              <div className="flex justify-center">
                <Badge className="bg-indigo-100 text-indigo-800">+50 Donor Points Earned</Badge>
              </div>
              <div className="mt-3 p-3 bg-green-50 rounded-lg">
                <p className="text-sm text-green-700 flex items-center justify-center">
                  <Users className="w-4 h-4 mr-2" />
                  Your donation could help up to 5 people in need
                </p>
              </div>
              <div className="mt-4 space-y-3">
                <p className="text-sm text-gray-600">Share your donation to inspire others:</p>
                <div className="flex justify-center space-x-3">
                  <Button variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                    <svg
                      className="w-5 h-5 mr-2"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                    Facebook
                  </Button>
                  <Button variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                    <svg
                      className="w-5 h-5 mr-2"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                    </svg>
                    Twitter
                  </Button>
                  <Button variant="outline" className="bg-green-50 text-green-600 border-green-200">
                    <svg
                      className="w-5 h-5 mr-2"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                    </svg>
                    LinkedIn
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Helper component for Info icon
const InfoIcon = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  )
}

export default DonorApp

