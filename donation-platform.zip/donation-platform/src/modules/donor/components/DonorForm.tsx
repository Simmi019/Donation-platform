import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

type FormData = {
  name: string;
  mobile: string;
  email: string;
  address: string;
  pinCode: string;
  city: string;
};

const DonorForm = () => {
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  // Function to show error as toast notification
  const showError = (message: string) => {
    toast.error(`${message}`, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      theme: "light",
    });
  };

  const onSubmit = (data: FormData) => {
    console.log("Form Data:", data);
    localStorage.setItem("donorData", JSON.stringify(data));

    setShowSuccess(true);
    setTimeout(() => {
      navigate("/donordashboard");
    }, 1000);
  };

  return (
    <div className="flex flex-col md:flex-row items-center justify-center min-h-screen bg-gray-100 py-10 px-5 w-full">
      {/* Toast Container for Error Popups */}
      <ToastContainer />

      <div className="w-full md:w-[90%] flex flex-col md:flex-row items-center">
        {/* Image Section */}
        <div className="hidden md:flex w-1/2 justify-center">
          <img src="/src/assets/donate.jpg" alt="Donor" className="w-full max-h-[80vh] object-cover rounded-lg shadow-lg" />
        </div>

        {/* Form Section */}
        <div className="bg-white w-full md:w-1/2 p-8 rounded-lg shadow-lg min-h-[550px]">
        <h2 className="text-2xl font-semibold mb-6 text-center text-gray-800">Donor Details</h2>
          <form
            onSubmit={handleSubmit(onSubmit, () => {
              // Show popups for errors
              if (errors.name) showError(errors.name.message as string);
              if (errors.mobile) showError(errors.mobile.message as string);
              if (errors.email) showError(errors.email.message as string);
              if (errors.address) showError(errors.address.message as string);
              if (errors.pinCode) showError(errors.pinCode.message as string);
              if (errors.city) showError(errors.city.message as string);
            })}
            className="space-y-4"
          >
            <input
              type="text"
              {...register("name", { required: "Full Name is required" })}
              placeholder="Full Name"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="tel"
              {...register("mobile", {
                required: "Mobile Number is required",
                pattern: { value: /^[0-9]{10}$/, message: "Invalid mobile number" },
              })}
              placeholder="Mobile Number"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="email"
              {...register("email", {
                required: "Email is required",
                pattern: { value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, message: "Invalid email format" },
              })}
              placeholder="Email ID"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="text"
              {...register("address", { required: "Address is required" })}
              placeholder="Address"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="text"
              {...register("pinCode", {
                required: "Pin Code is required",
                pattern: { value: /^[0-9]{6}$/, message: "Invalid Pin Code" },
              })}
              placeholder="Pin Code"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="text"
              {...register("city", { required: "City is required" })}
              placeholder="City"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <button type="submit" className="bg-blue-600 w-full text-white py-3 rounded-md hover:bg-blue-700 transition duration-200">
              Submit
            </button>
          </form>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm text-center">
            <span className="text-green-500 text-6xl">✔️</span>
            <h2 className="text-xl font-semibold mt-4 text-gray-800">Congrats Donor!</h2>
            <p className="text-gray-700">You are all set to go</p>
            <button onClick={() => setShowSuccess(false)} className="mt-4 w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200">
              Continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DonorForm;
