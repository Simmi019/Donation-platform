import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle,
  Camera,
  Plus,
  Calendar,
  MapPin,
  Award,
  Clock,
  Heart,
  ThumbsUp,
  Gift,
  Upload,
  XCircle,
  Book,
  Shirt,
  Gamepad2,
  Search,
  Filter,
  AlertTriangle,
  Bell,
  Users,
  Check,
  BarChart,
  Eye,
  Building,
  MessageSquare,
  HandHeart,
  CheckSquare,
  ListChecks,
} from "lucide-react"

// Mock real-time data for demonstration
const MOCK_REAL_TIME_UPDATES = [
  { type: "new_donation", message: "New children's books donation available in your area", time: "Just now" },
  {
    type: "request_accepted",
    message: "Your request for winter clothes was accepted by Divya",
    time: "2 minutes ago",
  },
  { type: "impact", message: "You've helped distribute items to 42 beneficiaries this month!", time: "10 minutes ago" },
  { type: "milestone", message: "You've reached Trusted Receiver status! +500 points", time: "1 hour ago" },
  { type: "community", message: "3 new donors joined from your neighborhood", time: "3 hours ago" },
]

// Mock analytics data
const RECEIVER_ANALYTICS = {
  monthly: [35, 42, 48, 52, 58, 62, 65],
  impact: 320,
  trend: "+15.2%",
  categories: {
    books: 45,
    clothes: 30,
    toys: 25,
  },
  topReceived: [
    { item: "Children's books", quantity: 85 },
    { item: "Winter clothing", quantity: 62 },
    { item: "School supplies", quantity: 48 },
  ],
}

const ReceiverDashboard = () => {
  const [showSuccess, setShowSuccess] = useState(false)
  const [requestTitle, setRequestTitle] = useState("")
  const [description, setDescription] = useState("")
  const [requestCategory, setRequestCategory] = useState("books")
  const [requestQuantity, setRequestQuantity] = useState<number>(1)
  const [activeTab, setActiveTab] = useState<string>("availableDonations")
  const [images, setImages] = useState<string[]>([])
  const [uploading, setUploading] = useState(false)
  const [pickupDate, setPickupDate] = useState("")
  const [showRequestForm, setShowRequestForm] = useState(false)
  const [realTimeUpdates, setRealTimeUpdates] = useState(MOCK_REAL_TIME_UPDATES)
  const [unreadUpdates, setUnreadUpdates] = useState(3)
  const [showNotifications, setShowNotifications] = useState(false)
  const [activeFilter, setActiveFilter] = useState<string | null>(null)
  const [pickupTimeWindow, setPickupTimeWindow] = useState<string>("flexible")
  const [beneficiaryCount, setBeneficiaryCount] = useState<number>(1)
  const [urgencyLevel, setUrgencyLevel] = useState<string>("medium")

  // Available donations that can be claimed
  const [availableDonations, setAvailableDonations] = useState<any[]>([
    {
      id: 1,
      items: "Children's Books",
      qty: "12",
      donor: "Divya",
      category: "books",
      condition: "Good",
      location: "Vasant Kunj, New Delhi",
      distance: "3.2 km away",
      time: "2 hours ago",
      match: 95,
    },
    {
      id: 2,
      items: "Winter Jackets",
      qty: "3",
      donor: "Rahul",
      category: "clothes",
      condition: "New",
      location: "Connaught Place, New Delhi",
      distance: "5.7 km away",
      time: "5 hours ago",
      match: 88,
    },
    {
      id: 3,
      items: "Educational Board Games",
      qty: "4",
      donor: "Priya",
      category: "toys",
      condition: "Used",
      location: "Greater Kailash, New Delhi",
      distance: "7.8 km away",
      time: "1 day ago",
      match: 75,
    },
  ])

  // Requests made by the receiver
  const [myRequests, setMyRequests] = useState<any[]>([
    {
      id: 1,
      items: "Children's Books",
      qty: "20",
      details: "For primary school library",
      category: "books",
      time: "2 days ago",
      status: "active",
      responses: 2,
    },
    {
      id: 2,
      items: "Winter Clothes",
      qty: "15",
      details: "For homeless shelter",
      category: "clothes",
      time: "1 week ago",
      status: "fulfilled",
      responses: 3,
    },
  ])

  // Scheduled pickups
  const [scheduledPickups, setScheduledPickups] = useState<any[]>([
    {
      id: 1,
      items: "Winter Jackets",
      donor: "Rahul",
      date: "Tomorrow, 2-4 PM",
      address: "10B, Connaught Place",
      status: "confirmed",
    },
  ])

  // Received donations history
  const [receivedDonations, setReceivedDonations] = useState<any[]>([
    {
      id: 1,
      items: "School Supplies",
      qty: "25",
      donor: "Ananya",
      category: "books",
      receivedDate: "Last week",
      beneficiaries: 15,
      status: "distributed",
    },
    {
      id: 2,
      items: "Toys",
      qty: "10",
      donor: "Vikram",
      category: "toys",
      receivedDate: "2 weeks ago",
      beneficiaries: 10,
      status: "distributed",
    },
  ])

  // Handle URL hash-based routing
  useEffect(() => {
    const validTabs = ["availableDonations", "myRequests", "received", "insights"]

    // Function to handle hash changes
    const handleHashChange = () => {
      const hash = window.location.hash.replace("#", "")
      if (validTabs.includes(hash)) {
        setActiveTab(hash)
      } else {
        // If invalid or no hash, set default and update URL without triggering a new navigation
        window.location.replace(`#${activeTab || "availableDonations"}`)
      }
    }

    // Initial check
    handleHashChange()

    // Listen for hash changes
    window.addEventListener("hashchange", handleHashChange)

    return () => {
      window.removeEventListener("hashchange", handleHashChange)
    }
  }, [])

  // Update URL hash when tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value)
    window.location.hash = value
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setUploading(true)

    // Simulate upload delay
    setTimeout(() => {
      setImages([...images, "/placeholder.svg?height=200&width=200"])
      setUploading(false)
    }, 1500)
  }

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmitRequest = () => {
    // Create new request
    const newRequest = {
      id: Date.now(),
      items: requestTitle,
      qty: requestQuantity.toString(),
      details: description.substring(0, 15) + (description.length > 15 ? "..." : ""),
      category: requestCategory,
      time: "just now",
      status: "active",
      responses: 0,
    }

    // Add to requests list
    setMyRequests((prev) => [newRequest, ...prev])

    // Show success message
    setShowSuccess(true)
    setTimeout(() => {
      setShowSuccess(false)
      setShowRequestForm(false)
      setImages([])
      setRequestTitle("")
      setDescription("")
      setPickupDate("")
    }, 3000)

    // Simulate real-time update
    setTimeout(() => {
      const newUpdate = {
        type: "request_posted",
        message: `Your request for ${requestTitle} has been posted and is visible to all donors`,
        time: "Just now",
      }
      setRealTimeUpdates((prev) => [newUpdate, ...prev])
      setUnreadUpdates((prev) => prev + 1)
    }, 4000)
  }

  const handleClaimDonation = (donationId: number) => {
    // Find the donation
    const donation = availableDonations.find((d) => d.id === donationId)

    if (donation) {
      // Add to scheduled pickups
      const newPickup = {
        id: Date.now(),
        items: donation.items,
        donor: donation.donor,
        date: "To be confirmed",
        address: donation.location,
        status: "pending",
      }

      setScheduledPickups((prev) => [newPickup, ...prev])

      // Remove from available donations
      setAvailableDonations((prev) => prev.filter((d) => d.id !== donationId))

      // Show success notification
      const newUpdate = {
        type: "donation_claimed",
        message: `You've claimed ${donation.items} from ${donation.donor}. Awaiting confirmation.`,
        time: "Just now",
      }
      setRealTimeUpdates((prev) => [newUpdate, ...prev])
      setUnreadUpdates((prev) => prev + 1)
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "books":
        return <Book className="w-4 h-4" />
      case "clothes":
        return <Shirt className="w-4 h-4" />
      case "toys":
        return <Gamepad2 className="w-4 h-4" />
      default:
        return <Gift className="w-4 h-4" />
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "books":
        return "bg-blue-100 text-blue-800"
      case "clothes":
        return "bg-purple-100 text-purple-800"
      case "toys":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getUpdateIcon = (type: string) => {
    switch (type) {
      case "new_donation":
        return <Gift className="w-4 h-4 text-green-500" />
      case "request_accepted":
        return <Check className="w-4 h-4 text-green-500" />
      case "impact":
        return <Users className="w-4 h-4 text-blue-500" />
      case "milestone":
        return <Award className="w-4 h-4 text-purple-500" />
      case "community":
        return <Heart className="w-4 h-4 text-pink-500" />
      case "request_posted":
        return <MessageSquare className="w-4 h-4 text-indigo-500" />
      case "donation_claimed":
        return <HandHeart className="w-4 h-4 text-orange-500" />
      default:
        return <Bell className="w-4 h-4 text-gray-500" />
    }
  }

  // Simulate receiving real-time updates periodically
  useEffect(() => {
    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * MOCK_REAL_TIME_UPDATES.length)
      const update = {
        ...MOCK_REAL_TIME_UPDATES[randomIndex],
        time: "Just now",
      }

      setRealTimeUpdates((prev) => [update, ...prev.slice(0, 9)])
      setUnreadUpdates((prev) => prev + 1)
    }, 45000) // Every 45 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-6">
      {/* Header with Real-time Notification Bell */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <HandHeart className="w-6 h-6 text-indigo-500 mr-2" />
          <h1 className="text-2xl font-bold text-indigo-700">DonateShare</h1>
        </div>

        <div className="relative">
          <Button
            variant="ghost"
            size="sm"
            className="relative"
            onClick={() => {
              setShowNotifications(!showNotifications)
              if (showNotifications) setUnreadUpdates(0)
            }}
          >
            <Bell className="w-5 h-5" />
            {unreadUpdates > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {unreadUpdates}
              </span>
            )}
          </Button>

          {/* Notification Panel */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
              <div className="p-3 border-b border-gray-100">
                <h3 className="font-medium">Recent Updates</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {realTimeUpdates.map((update, i) => (
                  <div key={i} className="p-3 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-3 mt-1">{getUpdateIcon(update.type)}</div>
                      <div>
                        <p className="text-sm text-gray-800">{update.message}</p>
                        <p className="text-xs text-gray-500 mt-1">{update.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Organization Stats Card */}
      <Card className="bg-white shadow-lg rounded-lg overflow-hidden mb-6 border-0">
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white">Welcome back, Winter Care Initiative</h1>
              <div className="flex items-center mt-1">
                <Badge className="bg-green-500 hover:bg-green-600">
                  <Award className="w-4 h-4 mr-1" /> Trusted Receiver
                </Badge>
              </div>
            </div>
            <div className="h-16 w-16 rounded-full bg-white shadow-md flex items-center justify-center">
              <Building className="h-8 w-8 text-indigo-600" />
            </div>
          </div>
        </div>

        <CardContent className="p-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            {[
              { icon: <Gift className="w-6 h-6 text-indigo-500" />, value: "42", label: "Received" },
              { icon: <Users className="w-6 h-6 text-blue-500" />, value: "320", label: "Beneficiaries" },
              { icon: <Award className="w-6 h-6 text-yellow-500" />, value: "1450", label: "Points" },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center p-3 rounded-lg bg-gray-50">
                <div className="mb-2">{stat.icon}</div>
                <p className="font-bold text-lg text-gray-800">{stat.value}</p>
                <p className="text-gray-500 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Scheduled Pickups */}
      {scheduledPickups.length > 0 && (
        <Card className="mb-6 border-0 shadow-lg bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold text-yellow-800 flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-yellow-600" /> Scheduled Pickups
              </h2>
            </div>

            {scheduledPickups.map((pickup, i) => (
              <div key={i} className="bg-white p-3 rounded-lg shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">{pickup.items}</h3>
                    <p className="text-sm text-gray-600">From: {pickup.donor}</p>
                    <div className="mt-1 space-y-1">
                      <p className="text-xs text-gray-500 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" /> {pickup.date}
                      </p>
                      <p className="text-xs text-gray-500 flex items-center">
                        <MapPin className="w-3 h-3 mr-1" /> {pickup.address}
                      </p>
                    </div>
                  </div>
                  <div>
                    <Badge
                      className={
                        pickup.status === "confirmed" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                      }
                    >
                      {pickup.status === "confirmed" ? "Confirmed" : "Pending"}
                    </Badge>
                    <Button size="sm" className="mt-2 bg-indigo-600 hover:bg-indigo-700 text-white">
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Live Activity Feed */}
      <div className="mb-6 px-2 py-3 bg-white bg-opacity-70 rounded-lg shadow-sm border border-indigo-100">
        <div className="flex items-center space-x-2">
          <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div>
          <p className="text-sm text-gray-600">
            <span className="font-medium text-indigo-600">Live:</span> 18 donors active now • 12 new donations in your
            area today
          </p>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full mb-6">
        <TabsList className="w-full grid grid-cols-4 mb-4">
          <TabsTrigger value="availableDonations" className="text-sm">
            Available
          </TabsTrigger>
          <TabsTrigger value="myRequests" className="text-sm">
            My Requests
          </TabsTrigger>
          <TabsTrigger value="received" className="text-sm">
            Received
          </TabsTrigger>
          <TabsTrigger value="insights" className="text-sm">
            Insights
          </TabsTrigger>
        </TabsList>

        <TabsContent value="availableDonations" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold flex items-center">
                  <Gift className="w-5 h-5 mr-2 text-indigo-500" /> Available Donations
                </h2>

                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input placeholder="Search donations" className="pl-8 h-8 w-40 text-sm" />
                  </div>
                  <Button variant="outline" size="sm" className="h-8">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Category filters */}
              <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                <Button
                  variant="outline"
                  size="sm"
                  className={`whitespace-nowrap ${!activeFilter ? "bg-indigo-50" : ""}`}
                  onClick={() => {
                    setActiveFilter(null)
                  }}
                >
                  All
                </Button>
                {["books", "clothes", "toys"].map((category) => (
                  <Button
                    key={category}
                    variant="outline"
                    size="sm"
                    className={`whitespace-nowrap ${activeFilter === category ? "bg-indigo-50" : ""}`}
                    onClick={() => {
                      setActiveFilter(category)
                    }}
                  >
                    <div className="flex items-center">
                      {getCategoryIcon(category)}
                      <span className="ml-1 capitalize">{category}</span>
                    </div>
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  className={`whitespace-nowrap ${activeFilter === "nearby" ? "bg-indigo-50" : ""}`}
                  onClick={() => {
                    setActiveFilter("nearby")
                  }}
                >
                  <MapPin className="w-4 h-4 mr-1" /> Nearby
                </Button>
              </div>

              {/* Real-time donation notification */}
              <div className="mb-4 p-3 bg-green-50 rounded-lg border border-green-200 flex items-center">
                <div className="flex-shrink-0 mr-3">
                  <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
                </div>
                <p className="text-sm text-green-800">
                  <span className="font-medium">Live updates:</span> Showing donations matching your organization's
                  needs
                </p>
              </div>

              <div className="space-y-3">
                {availableDonations.map((donation, i) => (
                  <div key={i} className="p-4 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-medium flex items-center">
                          {donation.match > 90 && <span className="mr-2 h-2 w-2 bg-green-500 rounded-full"></span>}
                          {donation.items}
                        </h3>
                        <p className="text-gray-800 font-medium mt-1 flex items-center">
                          {getCategoryIcon(donation.category)}
                          <span className="ml-1">
                            Qty: {donation.qty} • Condition: {donation.condition}
                          </span>
                        </p>
                      </div>
                      <div>
                        <Badge
                          className={`
                          ${
                            donation.match > 90
                              ? "bg-green-100 text-green-800"
                              : donation.match > 80
                                ? "bg-blue-100 text-blue-800"
                                : "bg-gray-100 text-gray-800"
                          }
                        `}
                        >
                          {donation.match}% Match
                        </Badge>
                      </div>
                    </div>

                    <div className="mt-2 text-sm text-gray-500 space-y-1">
                      <p className="flex items-center">
                        <MapPin className="w-3 h-3 mr-1" /> {donation.location} • {donation.distance}
                      </p>
                      <p className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" /> Posted {donation.time} • Donor: {donation.donor}
                      </p>
                    </div>

                    <div className="mt-3 flex space-x-2">
                      <Button
                        className="bg-indigo-600 hover:bg-indigo-700 text-white"
                        onClick={() => handleClaimDonation(donation.id)}
                      >
                        Claim Donation
                      </Button>
                      <Button variant="outline">Message Donor</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="myRequests" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              {myRequests.length === 0 && !showRequestForm ? (
                <div className="text-center py-8">
                  <MessageSquare className="w-12 h-12 text-indigo-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">No active requests yet</p>
                  <p className="text-gray-500 mb-4">Create a request to let donors know what your organization needs</p>
                  <Button
                    className="bg-indigo-600 text-white hover:bg-indigo-700 transition flex items-center mx-auto"
                    onClick={() => setShowRequestForm(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" /> Create New Request
                  </Button>
                </div>
              ) : !showRequestForm ? (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold">Your Requests</h2>
                    <Button
                      className="bg-indigo-600 text-white hover:bg-indigo-700 transition flex items-center"
                      onClick={() => setShowRequestForm(true)}
                    >
                      <Plus className="w-4 h-4 mr-2" /> New Request
                    </Button>
                  </div>

                  <div className="space-y-3">
                    {myRequests.map((request, i) => (
                      <div key={i} className="p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                        <div className="flex justify-between">
                          <div>
                            <div className="flex items-center">
                              {getCategoryIcon(request.category)}
                              <h3 className="font-medium ml-1">{request.items}</h3>
                            </div>
                            <p className="text-gray-500 text-sm">
                              {request.qty} items needed | {request.details}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge
                              className={
                                request.status === "active"
                                  ? "bg-green-100 text-green-800 hover:bg-green-200"
                                  : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                              }
                            >
                              {request.status === "active" ? "Active" : "Fulfilled"}
                            </Badge>

                            {request.status === "active" && (
                              <Button variant="outline" size="sm" className="h-7 text-xs">
                                Edit
                              </Button>
                            )}
                          </div>
                        </div>

                        <div className="flex justify-between items-center mt-2">
                          <p className="text-xs text-gray-500 flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> Posted {request.time}
                          </p>

                          {request.status === "active" && (
                            <div className="text-xs text-gray-500">
                              <span className="text-green-600 font-medium">{request.responses} responses</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                /* Request Form */
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold flex items-center">
                      <MessageSquare className="w-5 h-5 mr-2 text-indigo-500" /> New Request
                    </h2>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowRequestForm(false)}
                      className="text-gray-500 hover:text-red-500"
                    >
                      <XCircle className="w-5 h-5" />
                    </Button>
                  </div>

                  <Input
                    type="text"
                    placeholder="What do you need? (e.g. Children's books, Winter clothes)"
                    value={requestTitle}
                    onChange={(e) => setRequestTitle(e.target.value)}
                    className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                  />

                  <Textarea
                    placeholder="Description (age group, specific needs, purpose, etc.)"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500 min-h-24"
                  />

                  {/* Item Category */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Request Category</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "books", label: "Books", icon: <Book className="w-4 h-4 mr-2" /> },
                        { id: "clothes", label: "Clothes", icon: <Shirt className="w-4 h-4 mr-2" /> },
                        { id: "toys", label: "Toys", icon: <Gamepad2 className="w-4 h-4 mr-2" /> },
                      ].map((cat) => (
                        <Button
                          key={cat.id}
                          type="button"
                          variant={requestCategory === cat.id ? "default" : "outline"}
                          className={requestCategory === cat.id ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          onClick={() => setRequestCategory(cat.id)}
                        >
                          <div className="flex items-center">
                            {cat.icon}
                            {cat.label}
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Quantity Selection */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Quantity Needed</h3>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                      <span className="text-gray-700">Number of items</span>
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 w-8 p-0 rounded-full"
                          onClick={() => setRequestQuantity(Math.max(1, requestQuantity - 1))}
                        >
                          -
                        </Button>
                        <span className="w-6 text-center font-medium">{requestQuantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 w-8 p-0 rounded-full"
                          onClick={() => setRequestQuantity(requestQuantity + 1)}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Beneficiary Count */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Number of Beneficiaries</h3>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                      <span className="text-gray-700">People who will benefit</span>
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 w-8 p-0 rounded-full"
                          onClick={() => setBeneficiaryCount(Math.max(1, beneficiaryCount - 1))}
                        >
                          -
                        </Button>
                        <span className="w-6 text-center font-medium">{beneficiaryCount}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 w-8 p-0 rounded-full"
                          onClick={() => setBeneficiaryCount(beneficiaryCount + 1)}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Urgency Level */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Urgency Level</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "low", label: "Low" },
                        { id: "medium", label: "Medium" },
                        { id: "high", label: "High" },
                      ].map((level) => (
                        <Button
                          key={level.id}
                          type="button"
                          variant={urgencyLevel === level.id ? "default" : "outline"}
                          className={urgencyLevel === level.id ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          onClick={() => setUrgencyLevel(level.id)}
                        >
                          {level.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Upload Supporting Images */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-medium text-gray-700 flex items-center">
                      <Camera className="w-4 h-4 mr-2" /> Supporting Images (Optional)
                    </h3>

                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 transition-colors hover:border-indigo-500">
                      <div className="grid grid-cols-4 gap-2">
                        {images.map((img, i) => (
                          <div key={i} className="relative group">
                            <div className="h-24 w-full rounded-lg bg-gray-100 overflow-hidden">
                              <img
                                src={img || "/placeholder.svg"}
                                alt={`Support ${i + 1}`}
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <button
                              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => removeImage(i)}
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </div>
                        ))}

                        {images.length < 4 && (
                          <label className="h-24 w-full rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500 transition-colors">
                            <Upload className="w-6 h-6 text-gray-400" />
                            <span className="text-xs text-gray-500 mt-1">Upload</span>
                            <input
                              type="file"
                              className="hidden"
                              accept="image/*"
                              onChange={handleImageUpload}
                              disabled={uploading}
                            />
                          </label>
                        )}
                      </div>

                      {images.length === 0 && (
                        <div className="text-center mt-2">
                          <p className="text-sm text-gray-500">Add photos of your organization or beneficiaries</p>
                        </div>
                      )}

                      {uploading && (
                        <div className="mt-2">
                          <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-indigo-500 animate-pulse" style={{ width: "100%" }}></div>
                          </div>
                          <p className="text-xs text-center text-indigo-600 mt-1">Uploading image...</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Pickup Date */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-700 flex items-center">
                      <Calendar className="w-4 h-4 mr-2" /> Preferred Pickup/Delivery Date
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Date</p>
                        <Input
                          type="date"
                          value={pickupDate}
                          onChange={(e) => setPickupDate(e.target.value)}
                          className="border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Time Window</p>
                        <select
                          className="w-full h-10 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          value={pickupTimeWindow}
                          onChange={(e) => setPickupTimeWindow(e.target.value)}
                        >
                          <option value="morning">Morning (9AM - 12PM)</option>
                          <option value="afternoon">Afternoon (12PM - 4PM)</option>
                          <option value="evening">Evening (4PM - 7PM)</option>
                          <option value="flexible">Flexible (Anytime)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Organization info note */}
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <InfoIcon className="w-4 h-4 inline mr-1" /> Your organization details and verification status
                      will be visible to donors.
                    </p>
                  </div>

                  {/* Submit Button */}
                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        // Show preview logic would go here
                        alert("Preview functionality would show how your request will appear to donors")
                      }}
                    >
                      <Eye className="w-5 h-5 mr-2" /> Preview
                    </Button>
                    <Button
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white transition"
                      onClick={handleSubmitRequest}
                      disabled={uploading}
                    >
                      <MessageSquare className="w-5 h-5 mr-2" /> Submit Request
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="received" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold flex items-center">
                  <CheckSquare className="w-5 h-5 mr-2 text-green-500" /> Received Donations
                </h2>

                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input placeholder="Search received" className="pl-8 h-8 w-40 text-sm" />
                  </div>
                  <Button variant="outline" size="sm" className="h-8">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                {receivedDonations.map((donation, i) => (
                  <div key={i} className="p-4 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-medium flex items-center">
                          {getCategoryIcon(donation.category)}
                          <span className="ml-1">{donation.items}</span>
                        </h3>
                        <p className="text-gray-600 mt-1">
                          Quantity: {donation.qty} • From: {donation.donor}
                        </p>
                      </div>
                      <div>
                        <Badge
                          className={
                            donation.status === "distributed"
                              ? "bg-green-100 text-green-800"
                              : "bg-blue-100 text-blue-800"
                          }
                        >
                          {donation.status === "distributed" ? "Distributed" : "In Storage"}
                        </Badge>
                      </div>
                    </div>

                    <div className="mt-2 text-sm text-gray-500 space-y-1">
                      <p className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" /> Received: {donation.receivedDate}
                      </p>
                      <p className="flex items-center">
                        <Users className="w-3 h-3 mr-1" /> Beneficiaries: {donation.beneficiaries} people
                      </p>
                    </div>

                    <div className="mt-3 flex space-x-2">
                      <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                        <ListChecks className="w-4 h-4 mr-2" /> Distribution Details
                      </Button>
                      <Button variant="outline">
                        <ThumbsUp className="w-4 h-4 mr-2" /> Send Thanks
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="mt-0">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-4">
              <h2 className="text-lg font-semibold flex items-center mb-4">
                <BarChart className="w-5 h-5 mr-2 text-indigo-500" /> Impact & Analytics
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium text-indigo-700 mb-2">Monthly Donations Received</h3>
                  <div className="h-40 w-full">
                    {/* This would be your chart component */}
                    <div className="h-full w-full bg-white rounded-md flex items-end p-2 space-x-1">
                      {RECEIVER_ANALYTICS.monthly.map((val, i) => (
                        <div
                          key={i}
                          className="bg-indigo-500 rounded-t w-full"
                          style={{ height: `${(val / 65) * 100}%` }}
                        ></div>
                      ))}
                    </div>
                  </div>
                  <div className="mt-2 flex justify-between text-xs text-gray-500">
                    <span>Jan</span>
                    <span>Feb</span>
                    <span>Mar</span>
                    <span>Apr</span>
                    <span>May</span>
                    <span>Jun</span>
                    <span>Jul</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg border border-gray-100">
                    <h3 className="text-sm font-medium text-gray-500">People Helped</h3>
                    <div className="mt-2 flex items-baseline">
                      <span className="text-2xl font-bold text-indigo-700">{RECEIVER_ANALYTICS.impact}</span>
                      <span className="ml-2 text-sm text-green-600">{RECEIVER_ANALYTICS.trend}</span>
                    </div>
                    <div className="mt-2 text-xs text-gray-500">This year</div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-gray-100">
                    <h3 className="text-sm font-medium text-gray-500">Category Mix</h3>
                    <div className="mt-3 space-y-2">
                      {Object.entries(RECEIVER_ANALYTICS.categories).map(([category, percentage]) => (
                        <div key={category}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="capitalize">{category}</span>
                            <span>{percentage}%</span>
                          </div>
                          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${
                                category === "books"
                                  ? "bg-blue-500"
                                  : category === "clothes"
                                    ? "bg-purple-500"
                                    : "bg-yellow-500"
                              }`}
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-gray-100 col-span-2">
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Top Received Items</h3>
                    <div className="space-y-2">
                      {RECEIVER_ANALYTICS.topReceived.map((item, i) => (
                        <div key={i} className="flex items-center">
                          <div className="w-full">
                            <div className="flex justify-between text-xs mb-1">
                              <span>{item.item}</span>
                              <span className="text-indigo-600">{item.quantity} items</span>
                            </div>
                            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-indigo-500"
                                style={{ width: `${(item.quantity / 85) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-blue-700 mb-2">Donor Engagement</h3>
                <p className="text-sm text-blue-600 mb-3">Increase your visibility to donors with these actions:</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "Update Organization Profile", icon: <Building className="w-4 h-4 mr-1" /> },
                    { label: "Share Impact Stories", icon: <Heart className="w-4 h-4 mr-1" /> },
                    { label: "Post Specific Needs", icon: <MessageSquare className="w-4 h-4 mr-1" /> },
                    { label: "Send Thank You Notes", icon: <ThumbsUp className="w-4 h-4 mr-1" /> },
                  ].map((item, i) => (
                    <Button key={i} variant="outline" className="bg-white text-xs h-auto py-2 text-gray-700">
                      {item.icon}
                      {item.label}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Success Message Overlay */}
      {showSuccess && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-md">
            <div className="text-center">
              <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-green-100">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Request Posted Successfully!</h3>
              <p className="text-gray-500 mb-4">
                Your request is now visible to donors. We'll notify you when someone responds.
              </p>
              <div className="flex justify-center">
                <Badge className="bg-indigo-100 text-indigo-800">+50 Receiver Points Earned</Badge>
              </div>
              <div className="mt-3 p-3 bg-green-50 rounded-lg">
                <p className="text-sm text-green-700 flex items-center justify-center">
                  <Users className="w-4 h-4 mr-2" />
                  Your request could help up to {beneficiaryCount} people in need
                </p>
              </div>
              <div className="mt-4 space-y-3">
                <p className="text-sm text-gray-600">Share your request to reach more donors:</p>
                <div className="flex justify-center space-x-3">
                  <Button variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                    <svg
                      className="w-5 h-5 mr-2"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                    Facebook
                  </Button>
                  <Button variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                    <svg
                      className="w-5 h-5 mr-2"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                    </svg>
                    Twitter
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Helper component for Info icon
const InfoIcon = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  )
}

export default ReceiverDashboard

