import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

type FormData = {
  organization: string;
  contactPerson: string;
  mobile: string;
  email: string;
  address: string;
  pinCode: string;
  city: string;
  needs: string;
  registrationType: string; // Added field for registration type
};

const ReceiverForm = () => {
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  const showError = (message: string) => {
    toast.error(message, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      theme: "light",
    });
  };

  const onSubmit = (data: FormData) => {
    console.log("Form Data:", data);
    localStorage.setItem("receiverData", JSON.stringify(data));

    setShowSuccess(true);
    setTimeout(() => {
      navigate("/ReceiverDashboard");
    }, 1000);
  };

  return (
    <div className="flex flex-col md:flex-row items-center justify-center min-h-screen bg-gray-100 py-10 px-5 w-full overflow-hidden">
      <ToastContainer />

      <div className="w-full md:w-[90%] flex flex-col md:flex-row items-center">
        {/* Image Section */}
        <div className="hidden md:flex w-1/2 h-[80vh] justify-center items-center">
      <img
        src="./src/assets/receive.png"
        alt="Receiver"
        className="w-full h-full object-cover rounded-lg shadow-lg"/>
      </div>


        {/* Form Section */}
        <div className="bg-white w-full md:w-[50%] p-6 rounded-lg shadow-lg min-h-[80vh] max-h-[90vh] overflow-y-auto">
  <h2 className="text-2xl font-semibold mb-4 text-center text-gray-800">Receiver Details</h2>
  <form
    onSubmit={handleSubmit(onSubmit, () => {
      if (errors.organization) showError(errors.organization.message as string);
      if (errors.contactPerson) showError(errors.contactPerson.message as string);
      if (errors.mobile) showError(errors.mobile.message as string);
      if (errors.email) showError(errors.email.message as string);
      if (errors.address) showError(errors.address.message as string);
      if (errors.pinCode) showError(errors.pinCode.message as string);
      if (errors.city) showError(errors.city.message as string);
      if (errors.needs) showError(errors.needs.message as string);
      if (errors.registrationType) showError(errors.registrationType.message as string);
    })}
    className="space-y-3"
  >
    {/* Registration Type Dropdown */}
    <select
      {...register("registrationType", { required: "Please select your registration type" })}
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    >
      <option value="">Select Registration Type</option>
      <option value="Trust">Trust</option>
      <option value="NGO">NGO</option>
      <option value="Receiver">Receiver</option>
    </select>

    <input
      type="text"
      {...register("organization", { required: "Organization Name is required" })}
      placeholder="Organization Name"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <input
      type="text"
      {...register("contactPerson", { required: "Contact Person Name is required" })}
      placeholder="Contact Person"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <input
      type="tel"
      {...register("mobile", {
        required: "Mobile Number is required",
        pattern: { value: /^[0-9]{10}$/, message: "Invalid mobile number" },
      })}
      placeholder="Mobile Number"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <input
      type="email"
      {...register("email", {
        required: "Email is required",
        pattern: { value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, message: "Invalid email format" },
      })}
      placeholder="Email ID"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <input
      type="text"
      {...register("address", { required: "Address is required" })}
      placeholder="Address"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <input
      type="text"
      {...register("pinCode", {
        required: "Pin Code is required",
        pattern: { value: /^[0-9]{6}$/, message: "Invalid Pin Code" },
      })}
      placeholder="Pin Code"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <input
      type="text"
      {...register("city", { required: "City is required" })}
      placeholder="City"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
    />

    <textarea
      {...register("needs", { required: "Please specify your organization's needs" })}
      placeholder="Describe what your organization needs (e.g., food, clothes, books, etc.)"
      className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500"
      rows={3}
    />

    <button type="submit" className="bg-black hover:bg-black-600 w-full text-white py-3 rounded-md hover:bg-grey-700 transition duration-200">
      Submit
    </button>
  </form>
</div>
</div>
      
{showSuccess && (
  <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-50">
    <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm text-center">
      <span className="text-green-500 text-6xl">✔️</span>
      <h2 className="text-xl font-semibold mt-4 text-gray-800">Registration Successful!</h2>
      <p className="text-gray-700">Your organization is now ready to receive donations.</p>
      <button 
        onClick={() => navigate("/ReceiverDashboard")} 
        className="mt-4 w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition duration-200">
        Go to Dashboard
      </button>
    </div>
  </div>
)}
    </div>
  );
};

export default ReceiverForm