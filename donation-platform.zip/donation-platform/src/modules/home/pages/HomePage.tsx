import { Routes, Route } from "react-router-dom";

import Login from "@/modules/user/components/Login";
import Navbar from "../components/Navbar";
import Home from "../components/Home";
import SignUp from "@/modules/user/components/SignUp";
import PrivateRoute from "@/routing/PrivateRoutes";
import About from "../components/About";
import Services from "../components/Services";
import Contact from "../components/Contact";
import Receiver from "@/modules/receiver/components/ReceiverForm";
import Category from "@/modules/category/components/Category";
import DonorForm from "@/modules/donor/components/DonorForm";
import DonorDashboard from "@/modules/donor/components/DonorDashboard";
import ReceiverDashboard from "@/modules/receiver/components/ReceiverDashboard";

const HomePage = () => {
  return (
<div className="relative h-[100vh] " 
    >
        <Navbar />
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/services" element={<Services/>} />
          <Route path="/contact" element={<Contact/>} />
          <Route path="/category" element={<PrivateRoute><Category/></PrivateRoute>} />
          {/* <Route path="/about" element={<PrivateRoute><About/></PrivateRoute>} /> */}
          {/* <Route path="/services" element={<PrivateRoute><Services/></PrivateRoute>} /> */}
          {/* <Route path="/contact" element={<PrivateRoute><Contact/></PrivateRoute>} /> */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />

          {/* For category */}
          <Route path="/donor" element={<DonorForm/>}></Route>
          <Route path="/receiver" element={<Receiver/>}></Route>

          {/* Donor */}
          <Route path="/donordashboard" element={<DonorDashboard/>}></Route>
          <Route path="/receiverdashboard" element={<ReceiverDashboard/>}></Route>
        </Routes>
      </div>
  );
};

export default HomePage;
