import  { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
// import Navbar from '../components/Navbar';

// Simple SVG icons components
const ChevronLeft = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
    <polyline points="15 18 9 12 15 6" />
  </svg>
);

const ChevronRight = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
    <polyline points="9 18 15 12 9 6" />
  </svg>
);

const ChevronUp = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
    <polyline points="18 15 12 9 6 15" />
  </svg>
);

const QuoteIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-16 h-16">
    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1-0.5 1-1V6h2v3.587C7 13.764 4.5 16 1 16v5h2zm14 0c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2a.99.99 0 001-1V6h2v3.587C21 13.764 18.5 16 15 16v5h2z" />
  </svg>
);

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);

  const navigate = useNavigate();
  const slides = [
    {
      image: "https://plus.unsplash.com/premium_photo-1661964021703-59bbdcdbfdab?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8ZG9uYXRpb258ZW58MHx8MHx8fDA%3D",
      subtitle: "Make a Difference",
      title: ["Donate Your Unused Items", "and Help Those in Need"],
      text: "Join us in reducing waste and supporting communities."
    },
    {
      image: "https://images.pexels.com/photos/6994982/pexels-photo-6994982.jpeg?auto=compress&cs=tinysrgb&w=600",
      subtitle: "Support Your Community",
      title: ["Every Item Counts", "Your Donation Matters"],
      text: "Help us create a sustainable future by donating what you no longer need."
    },
    {
      image: "https://images.pexels.com/photos/8580732/pexels-photo-8580732.jpeg?auto=compress&cs=tinysrgb&w=600",
      subtitle: "Join the Movement",
      title: ["Together We Can", "Make a Change"],
      text: "Your unused items can bring joy to someone else."
    }
  ];

  const services = [
    {
      image: "https://plus.unsplash.com/premium_photo-1683134050449-080429c850a4?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8ZG9uYXRpb24lMjBwaWNrdXB8ZW58MHx8MHx8fDA%3D",
      title: "Donation Pickup",
      link: "SCHEDULE PICKUP"
    },
    {
      image: "https://thumbs.dreamstime.com/b/young-black-male-courier-happy-delivery-technology-tracking-courier-service-concept-young-black-male-courier-happy-287484653.jpg?w=768",
      title: "Track Donations",
      link: "VIEW TRACKING"
    },
    {
      image: "https://t4.ftcdn.net/jpg/10/53/84/93/240_F_1053849316_8I4pCZTleaMUJOm9rVnAT7Gbv5QpMx1S.jpg",
      title: "Rewards for Donors",
      link: "LEARN MORE"
    }
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden" id="HomePage">
      <div className="absolute inset-0 transition-opacity duration-700 ease-in-out">
          <img 
            src={slides[currentSlide].image} 
            alt="Hero" 
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>

        <div className="relative h-full flex items-center justify-center text-center text-white">
          <div className="max-w-4xl px-4 animate-fadeIn">
            <p className="text-lg mb-4 opacity-90 animate-slideDown">{slides[currentSlide].subtitle}</p>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-slideUp">
              {slides[currentSlide].title[0]} <br />
              {slides[currentSlide].title[1]}
            </h1>
            <p className="text-xl mb-8 animate-slideUp">{slides[currentSlide].text}</p>
            <button className="border-2 border-[#ffbf69] text-white px-8 py-3 rounded-[4px] hover:bg-[#ffbf69] font-bold transition-all duration-300 hover:scale-105 hover:shadow-lg animate-slideUp"  onClick={() => navigate("/login")}>
              START DONATING
            </button>
          </div>
        </div>

         {/* Navigation buttons with hover effects */}
         <button 
          onClick={prevSlide}
          className="absolute left-4 border-2 border-[#ffbf69] top-1/2 -translate-y-1/2 p-2 bg-transparent  transition-all duration-300 transform rotate-45 w-10 h-10 flex items-center justify-center hover:scale-110"
        >
          <div className="-rotate-45 text-[#ffbf69] hover:text-white transition-colors duration-300">
            <ChevronLeft />
          </div>
        </button>

        <button 
          onClick={nextSlide}
          className="absolute right-4 border-2 border-[#ffbf69] top-1/2 -translate-y-1/2 p-2 bg-transparent transition-all duration-300 transform rotate-45 w-10 h-10 flex items-center justify-center hover:scale-110"
        >
          <div className="-rotate-45 text-[#ffbf69] hover:text-white transition-colors duration-300">
            <ChevronRight />
          </div>
        </button>
    
      </section>

      {/* Services Section */}
      <section className="py-20 bg-black" id='services'>
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6 text-white">Our Services</h2>
          <p className="text-white mb-12 max-w-2xl mx-auto text-bold">
            Give&Gather connects donors with NGOs and communities in need, making the donation process seamless and rewarding.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-black border-4 border-white overflow-hidden shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl transform hover:-translate-y-2"
            >
              <img 
                src={service.image} 
                alt={service.title} 
                className="w-full h-64 object-cover transition-transform duration-300 hover:scale-110"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4 text-white">{service.title}</h3>
                <a href="#" className="hover:underline text-[#ffbf69] transition-colors duration-300 hover:text-white">
                  {service.link}
                </a>
              </div>
            </div>
          ))}
        </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-black" id="about">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="text-center md:text-left flex flex-col justify-center items-center">
              <p className=" text-lg mb-4 text-center text-[#ffbf69]">OUR MISSION</p>
              <h2 className="text-4xl font-bold mb-6 text-white">Giving Back to the Community</h2>
              <p className="text-white mb-8 p-8 text-center">
                Give&Gather aims to reduce waste and promote sustainable practices by connecting individuals with surplus goods to those in need. Join us in making a difference!
              </p>
              <div className="mb-8">
                <p className="text-gray-500 mb-2 text-center">Contact Us</p>
                <a href="tel:+918729390088" className="text-2xl font-bold hover:underline text-white">+91 87293 90088</a>
              </div>
              <button className="bg-transparent text-white px-8 py-3 border-2 border-[#ffbf69] font-bold rounded-[4px] hover:bg-blue-700 transition-colors">
                Read More
              </button>
            </div>
            <div className="relative">
              <img src="https://media.istockphoto.com/id/2171791937/photo/close-up-of-volunteers-arranging-clothes-for-donation-outdoors.webp?a=1&b=1&s=612x612&w=0&k=20&c=wxLFes8cESDbFX-016Is3mAJYBTPSNpg3l9VadBC4fU=" alt="About" className="w-full rounded-lg shadow-xl" />
              <img 
                src="https://images.unsplash.com/photo-1542627088-6603b66e5c54?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8ZG9uYXRpb258ZW58MHx8MHx8fDA%3D" 
                alt="Feature" 
                className="absolute -bottom-12 -left-12 w-64 h-64 rounded-lg shadow-xl "
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 bg-[#363636] text-white">
        <div className="container mx-auto px-4 text-center">
          <QuoteIcon />
          <p className="text-2xl md:text-3xl font-light mb-8 max-w-3xl mx-auto">
            "Donating my unused items was a rewarding experience. I felt like I was making a real difference!"
          </p>
          <div className="flex justify-center gap-2 mb-8">
            <div className="w-16 h-1 bg-white rounded" />
            <div className="w-16 h-1 bg-white rounded" />
            <div className="w-16 h-1 bg-white rounded" />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#363636] text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 Give&Gather. All Rights Reserved </p>
        </div>
      </footer>

      {/* Back to Top Button */}
      {isScrolled && (
        <button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-8 right-8 p-2 bg-[#ffbf69] text-white rounded-full shadow-lg  transition-colors"
        >
          <ChevronUp />
        </button>
      )}

    </div>
  );
};

export default Home;