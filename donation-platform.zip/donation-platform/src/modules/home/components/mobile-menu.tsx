
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import { type ReactNode, useState } from "react"

interface MobileMenuProps {
  children: ReactNode
  trigger?: ReactNode
}

export function MobileMenu({ children, trigger }: MobileMenuProps) {
  const [open, setOpen] = useState(false)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        )}
      </SheetTrigger>
      <SheetContent side="left" className="w-[80%] max-w-sm">
        {children}
      </SheetContent>
    </Sheet>
  )
}

