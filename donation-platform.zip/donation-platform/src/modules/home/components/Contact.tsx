const Contact = () => {
  return (
    <div className="text-white">Contact</div>
  )
}

export default Contact