
// import LoginPage from "./modules/user/pages/LoginPage"

import HomePage from "./modules/home/pages/HomePage"
// import SessionTimeout from "./components/SessionTimeout"

const App = () => {
  return (
    <>
    {/* <LoginPage/> */}
    <HomePage/>
    {/* <SessionTimeout/> */}
    </>
  )
}

export default App


