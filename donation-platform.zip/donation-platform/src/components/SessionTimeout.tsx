// import { useEffect } from "react";
// import { useNavigate } from "react-router-dom";

// const TIMEOUT_DURATION = 1 * 60 * 1000; // 1 minute

// const SessionTimeout: React.FC = () => {
//   const navigate = useNavigate();

//   useEffect(() => {
//     const resetTimer = () => {
//       localStorage.setItem("lastActivity", Date.now().toString());
//     };

//     const checkTimeout = () => {
//       const lastActivity = localStorage.getItem("lastActivity");
//       if (lastActivity && Date.now() - parseInt(lastActivity) > TIMEOUT_DURATION) {
//         alert("Session expired! Logging out...");
//         localStorage.removeItem("user"); // Clear session
//         navigate("/login");
//       }
//     };

//     resetTimer(); // Update session timestamp
//     const interval = setInterval(checkTimeout, 1000); // Check session every second

//     window.addEventListener("mousemove", resetTimer);
//     window.addEventListener("keypress", resetTimer);

//     return () => {
//       clearInterval(interval);
//       window.removeEventListener("mousemove", resetTimer);
//       window.removeEventListener("keypress", resetTimer);
//     };
//   }, [navigate]);

//   return null;
// };

// export default SessionTimeout;
